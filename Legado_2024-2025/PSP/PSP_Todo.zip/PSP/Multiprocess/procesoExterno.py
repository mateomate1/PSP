import random
import time
import sys


a = random.randint(0,20)
time.sleep(1)
sys.stdout.write(str(a))