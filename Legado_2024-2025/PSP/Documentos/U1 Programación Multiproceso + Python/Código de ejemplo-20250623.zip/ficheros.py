
def main():
    fp = open("texto.txt", "r", encoding="utf-8")
    contenido = fp.read()
    print(contenido)
    fp.close()

    with open("texto.txt", "r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()
    print(lineas)

    with open("texto.txt", "r", encoding="utf-8") as archivo:
        for linea in archivo:
            print(linea)


main()








