import subprocess
import time

def CrearProceso():
  try:
    proc = subprocess.Popen('notepad.exe')
    return proc
  except OSError as e:
    print(e.strerror)

    
p = CrearProceso()
time.sleep(5)

