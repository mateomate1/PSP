import os

id = os.getpid()
print(id)
os.execvp('notepad.exe', ['notepad.exe', 'C:/Users/profesor/Documents/mifichero.txt'])
print("Aquí no llego ...")

