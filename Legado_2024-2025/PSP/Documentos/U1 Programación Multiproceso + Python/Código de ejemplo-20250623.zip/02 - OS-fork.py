# fork solo funciona en unix/macos
import os
import time

def padre():
   while True:
      newpid = os.fork()
      if newpid == 0:
         hijo()
      else:
         print("Padre: {}, Hijo: {}".format(os.getpid(), newpid))
      reply = input("Pulsa 's' si quieres crear un nuevo proceso ")
      if reply != 's': 
         break
        
def hijo():
   print('\n Hijo creado con pid %d ' % os.getpid())
   time.sleep(50)
   os._exit(0)  

padre()