import numpy as np

def myMatMul(a,b):
    c=[]
    cRows = len(b)
    cCols = len(a[0])
    for i in range(cRows):
        ci = []
        for j in range(cCols):
            elem = 0
            for ai in range(len(a[i])):
                ae = a[i][ai]
                be = b[ai][j]
                elem = elem + ae*be
            ci.append(elem)
        c.append(ci)
    return(c)

def main():
    a =[[1,2,3,4,5],
        [0,1,2,3,4],
        [0,0,1,2,3],
        [0,0,0,1,2],
        [0,0,0,0,1]]
    b = [[5,4,3,2,1], 
        [4,3,2,3,4],
        [0,0,1,0,3],
        [0,2,0,1,2],
        [5,0,0,0,1]]
    c = myMatMul(a,b)
    for ci in c:
        cad = ' ['
        for i in ci:
            cad += str(i)+' '
        print(cad+']')

    a1 = np.array(a)
    a2 = np.array(b)
    conN = np.matmul(a1,a2)
    print(conN)

if __name__ == "__main__":
    main()

