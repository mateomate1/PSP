import psutil

p = psutil.Process()
print(p.name())  
print(p.exe())
print(p.cpu_times())  
print(p.cpu_percent())  
print(p.create_time())  
print(p.ppid())
print(p.status())
#print(p.environ())
print(p.nice())
