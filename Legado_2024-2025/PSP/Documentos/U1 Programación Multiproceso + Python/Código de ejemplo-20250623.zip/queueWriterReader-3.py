
from multiprocessing import Process, Queue
import os
import time

def leo(q):
    end = False
    cadena = ''
    while not end:
        texto = q.get()
        if texto == '--':
            end = True
        else:
            cadena += texto
            print (cadena)
    print("Salgo del proceso hijo {}".format(os.getpid()))
    os._exit(0)

def main():
    myQ = Queue(maxsize=1000)
    end = False

    rp = Process(target=leo, args=(myQ, ))
    rp.start()
    #rp.join()

    while not end:
        line = input("Introduce mensaje: ")
        if line == '--':
            end = True
        myQ.put(line)      
        time.sleep(3)
    print("Salgo del proceso padre {}".format(os.getpid()))

if __name__ == '__main__':
  main()

