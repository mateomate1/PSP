#from fastapi import FastAPI, Body
import fastapi
import uvicorn
import json

app = fastapi.FastAPI()

@app.get("/info")
def info():
    return {"contenido": "Hola, estás en mi API", "autor": "Agustin"}

@app.get("/saludamemas/{nombre}/{edad}")
# Formato de la llamada URLBASE/saludamemas/Maite/17
def saludo2(nombre: str, edad: int):
    return {"contenido": "Hola {} ¿Cómo estás a tus {} años?".format(nombre, edad), "autor": "Agustin"}

@app.get("/saludame")
# Formato de la llamada URLBASE/saludame?nombre=Maite&edad=17
def saludo(nombre: str, edad: int):
    return {"contenido": "Hola {}. Tienes {} años".format(nombre, edad), "autor": "Agustin"}

'''
@app.post("/items/")
# formato de la llamada URLBASE/items/ y en un body con el siguiente JSON {"nombre":"Maite", "edad":56}
def create_item(elem: dict = fastapi.Body(...)):
    print(type(elem))
    value = {"contenido": "Hola {}, tienes {} años".format(elem['nombre'], elem['edad']), "autor": "Agustin"}
    return(value)

@app.put("/tomajson/")
# formato de la llamada URLBASE/tomajson/ y en un body con el siguiente JSON {"nombre":"Maite", "edad":56}
def tomajson(nombre: str = fastapi.Body(...), edad: int = fastapi.Body(...)):
    n = nombre
    e = edad
    value = {"contenido": "Hola {}, tienes {} años".format(n, e), "autor": "Agustin"}
    return(value)
'''
if __name__ == "__main__":
    #uvicorn.run(app, host="192.168.1.40", port=8090)
    uvicorn.run(app, host="10.231.1.94", port=8090)

# Accede a la documentación con http://url:port/docs